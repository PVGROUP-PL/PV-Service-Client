import React from 'react';
import { Link } from 'react-router-dom'; // Import do tworzenia linków
import LoginForm from './LoginForm';

function LoginPage() {
  return (
    <div>
      {/* NOWY LINK POWROTNY */}
      <nav>
        <Link to="/">Powrót do strony głównej</Link>
      </nav>
      <h1>Panel Właściciela</h1>
      <p>Zaloguj się, aby zarządzać swoimi food truckami.</p>
      <LoginForm />
    </div>
  );
}

export default LoginPage;