import React, { useState, useEffect } from 'react';

// Mały, pomocniczy komponent do panelu właściciela
function OwnerDashboard({ user }) {
  const [trucks, setTrucks] = useState([]);
  const [message, setMessage] = useState('Ładowanie danych...');

  useEffect(() => {
    const fetchMyTrucks = async () => {
      const token = localStorage.getItem('token');
      try {
        const response = await fetch('http://localhost:3000/api/trucks/my-truck', {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        const data = await response.json();
        if (response.ok) {
          setTrucks(data);
          setMessage(data.length === 0 ? 'Nie dodałeś jeszcze żadnego food trucka.' : '');
        } else {
          setMessage(`Błąd: ${data.message}`);
        }
      } catch (error) {
        setMessage('Błąd sieci.');
      }
    };
    fetchMyTrucks();
  }, []);

  return (
    <div>
      <h2>Twoje Food Trucki:</h2>
      {trucks.length > 0 ? (
        <ul>
          {trucks.map(truck => <li key={truck.truck_id}><h3>{truck.truck_name}</h3></li>)}
        </ul>
      ) : (<p>{message}</p>)}
    </div>
  );
}

// Mały, pomocniczy komponent do panelu organizatora
function OrganizerDashboard({ user }) {
  // W przyszłości tutaj będziemy pobierać listę rezerwacji tego organizatora
  return (
    <div>
      <h2>Twoje Rezerwacje:</h2>
      <p>Ta sekcja jest w budowie. Wkrótce zobaczysz tutaj listę swoich rezerwacji.</p>
    </div>
  );
}


// Główny komponent DashboardPage, który decyduje, co pokazać
function DashboardPage() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Odczytujemy dane użytkownika z localStorage
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData)); // Zamieniamy tekst z powrotem na obiekt
    }
  }, []);

  // Jeśli dane użytkownika się jeszcze nie załadowały
  if (!user) {
    return <h1>Ładowanie panelu...</h1>;
  }

  return (
    <div>
      <h1>Panel Główny</h1>
      <p>Witaj, {user.email}!</p>
      
      {/* Tutaj dzieje się magia - renderujemy komponent w zależności od typu użytkownika */}
      {user.user_type === 'owner' && <OwnerDashboard user={user} />}
      {user.user_type === 'organizer' && <OrganizerDashboard user={user} />}

      {/* W przyszłości tutaj dodamy przycisk do wylogowania */}
    </div>
  );
}

export default DashboardPage;