// src/TruckCard.jsx

import React from 'react';
import { Link } from 'react-router-dom'; // <-- NOWY IMPORT
import './TruckCard.css';

function TruckCard({ truck }) {
  // Zwróć uwagę, że cały div jest teraz opakowany w Link,
  // który prowadzi do dynamicznej ścieżki /trucks/ID_TRUCKA
  return (
    <Link to={`/trucks/${truck.truck_id}`} className="truck-card-link">
      <div className="truck-card">
        <h3>{truck.truck_name}</h3>
        <p><strong>Kuchnia:</strong> {truck.cuisine_types}</p>
        <p><strong>Baza:</strong> {truck.base_postal_code}</p>
      </div>
    </Link>
  );
}

// Dodajmy jeszcze prosty styl do App.css dla linku, aby nie był niebieski i podkreślony
// .truck-card-link { text-decoration: none; color: inherit; }

export default TruckCard;