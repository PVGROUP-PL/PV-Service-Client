import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';

function TruckDetailsPage() {
  const { truckId } = useParams();
  const [truck, setTruck] = useState(null);
  const [message, setMessage] = useState('Ładowanie danych...');

  useEffect(() => {
    const fetchTruckDetails = async () => {
      // ... (logika pobierania danych pozostaje bez zmian)
      try {
        const response = await fetch(`http://localhost:3000/api/trucks/${truckId}`);
        const data = await response.json();
        if (response.ok) { setTruck(data); setMessage(''); } else { setMessage(`Błąd: ${data.message}`); }
      } catch (error) { setMessage('Błąd sieci.'); console.error('Błąd pobierania danych:', error); }
    };
    fetchTruckDetails();
  }, [truckId]);

  return (
    <div>
      <nav style={{ padding: '1rem' }}>
        <Link to="/">Powrót do wyszukiwarki</Link>
      </nav>
      {truck ? (
        <div>
          <h1>{truck.truck_name}</h1>
          <p><strong>Opis:</strong> {truck.description}</p>
          <p><strong>Typy kuchni:</strong> {truck.cuisine_types}</p>
          {/* ... reszta danych ... */}

          {/* --- NOWY PRZYCISK --- */}
          <div style={{ marginTop: '2rem' }}>
            <Link to={`/trucks/${truckId}/book`}>
              <button>Zarezerwuj ten Food Truck</button>
            </Link>
          </div>
          {/* -------------------- */}
        </div>
      ) : (
        <p>{message}</p>
      )}
    </div>
  );
}

export default TruckDetailsPage;