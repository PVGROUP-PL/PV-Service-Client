// src/HomePage.jsx

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import TruckCard from './TruckCard'; // <-- NOWY IMPORT

function HomePage() {
  const [postalCode, setPostalCode] = useState('');
  const [cuisine, setCuisine] = useState('');
  const [trucks, setTrucks] = useState([]);
  const [message, setMessage] = useState('Wpisz kod pocztowy eventu, aby rozpocząć wyszukiwanie.');

  const handleSearch = async (event) => {
    event.preventDefault();
    setMessage('Szukanie...');
    setTrucks([]);

    const searchParams = new URLSearchParams({ event_postal_code: postalCode });
    if (cuisine) {
      searchParams.append('cuisine', cuisine);
    }

    try {
      const response = await fetch(`http://localhost:3000/api/trucks?${searchParams.toString()}`);
      const data = await response.json();

      if (response.ok) {
        setTrucks(data);
        if (data.length === 0) {
          setMessage('Nie znaleziono żadnych food trucków pasujących do Twoich kryteriów.');
        } else {
          setMessage('');
        }
      } else {
        setMessage(`Błąd: ${data.message}`);
      }
    } catch (error) {
      setMessage('Błąd sieci.');
      console.error('Błąd wyszukiwania:', error);
    }
  };

  return (
    <div>
      <nav style={{ padding: '1rem', textAlign: 'right' }}>
        <Link to="/login">Zaloguj się (dla właścicieli)</Link>
      </nav>
      
      <h1>Znajdź idealnego Food Trucka na Twój Event</h1>
      
      <form onSubmit={handleSearch}>
        {/* ... formularz pozostaje bez zmian ... */}
        <div><label>Kod pocztowy eventu:</label><input type="text" value={postalCode} onChange={(e) => setPostalCode(e.target.value)} placeholder="np. 00-001" required /></div>
        <div><label>Typ kuchni (opcjonalnie):</label><input type="text" value={cuisine} onChange={(e) => setCuisine(e.target.value)} placeholder="np. burgery" /></div>
        <button type="submit">Szukaj</button>
      </form>

      <hr />

      <h2>Wyniki wyszukiwania:</h2>
      {/* ZMIANA TUTAJ: Zamiast <ul>, używamy <div> i komponentu TruckCard */}
      <div className="truck-list">
        {trucks.length > 0 ? (
          trucks.map(truck => (
            <TruckCard key={truck.truck_id} truck={truck} />
          ))
        ) : (
          <p>{message}</p>
        )}
      </div>
    </div>
  );
}

export default HomePage;