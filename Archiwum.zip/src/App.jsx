import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginPage from './LoginPage';
import DashboardPage from './DashboardPage';
import ProtectedRoute from './ProtectedRoute';
import HomePage from './HomePage';
import TruckDetailsPage from './TruckDetailsPage';
import BookingPage from './BookingPage'; // <-- NOWY IMPORT
import './App.css';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/trucks/:truckId" element={<TruckDetailsPage />} />

        {/* Grupa ścieżek chronionych */}
        <Route element={<ProtectedRoute />}>
          <Route path="/dashboard" element={<DashboardPage />} />
          {/* NOWA CHRONIONA ŚCIEŻKA DO REZERWACJI */}
          <Route path="/trucks/:truckId/book" element={<BookingPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;